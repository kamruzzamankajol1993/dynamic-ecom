<div class="table-responsive position-relative" style="min-height: 300px;">
    <div class="loading-spinner" style="display: none; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
        <div class="spinner-border text-primary" role="status"></div>
    </div>
    <table class="table table-hover">
        <thead>
            <tr>
                <th>Date</th>
                <th class="text-end">Total Revenue</th>
                <th class="text-end">Total Expense</th>
                <th class="text-end">Net Income</th>
            </tr>
        </thead>
        <tbody id="table-body"></tbody>
    </table>
</div>
