@extends('admin.master.master')

@section('title')
Panel Management | {{ $ins_name }}
@endsection

@section('css')
<style>
    .table-bordered {
        border: 1px solid #ccc;
        border-collapse: collapse;
    }

    .table-bordered th,
    .table-bordered td {
        border: 1px solid #ccc;
        padding: 8px 12px;
        vertical-align: middle;
    }

    th.sortable {
        cursor: pointer;
    }

    th.sortable {
        background-color: #f8f9fa;
    }
</style>
@endsection

@section('body')
<main class="main-content">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
            <h2 class="mb-0">Panel Settings</h2>
            <div class="d-flex align-items-center gap-2">
                <input class="form-control" id="searchInput" type="search" placeholder="Search..." style="max-width: 250px;">

                <select class="form-select" id="invoiceFilter" style="width: auto; white-space: nowrap;">
                    <option selected disabled>Export...</option>
                    <option value="excel">Export to Excel</option>
                    <option value="pdf">Export to PDF</option>
                </select>

                @if (Auth::user()->can('panelSettingAdd'))
                <a href="{{ route('systemInformation.create') }}" class="btn text-white" style="background-color: var(--primary-color); white-space: nowrap;">
                    <i class="fas fa-plus me-1"></i> Add New
                </a>
                @endif
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                @include('flash_message')
                <div class="table-responsive">
                    <table class="table table-hover table-bordered">
                        <thead>
                            <tr>
                                <th class="sortable" style="width:5%">Sl</th>
                                <th style="width:15%" class="sortable" data-column="branch_name">Branch Name</th>
                                <th style="width:5%" class="sortable" data-column="icon">Icon</th>
                                <th style="width:10%" class="sortable" data-column="logo">Logo</th>
                                <th style="width:15%" class="sortable" data-column="name">Name</th>
                                <th style="width:15%" class="sortable" data-column="phone">Contact Phone</th>
                                <th style="width:15%" class="sortable" data-column="email">Contact Email</th>
                                <th style="width:10%" class="sortable">Action</th>
                            </tr>
                        </thead>
                        <tbody id="tableBody">
                            </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer bg-white d-flex justify-content-between align-items-center">
                <div class="text-muted" id="pagination-info"></div>
                <nav>
                    <ul class="pagination justify-content-center mb-0" id="pagination"></ul>
                </nav>
            </div>
        </div>
    </div>
</main>
@endsection

@section('script')
@include('admin.panelSettingInfo._partial.script')
@endsection